import serial
import time
from bottle import get,post,run,request,template

ser = serial.Serial("/dev/ttyS0", 115200)

buff=1;

def usart_fpag(dat):
    if dat==1:
        ser.write('\x00'.encode());
    elif dat==2:
        ser.write('\x01'.encode());
    elif dat==3:
        ser.write('\x02'.encode());
    elif dat==4:
        ser.write('\x03'.encode());
    elif dat==5:
        ser.write('\x04'.encode());
    elif dat==6:
        ser.write('\x05'.encode());
    elif dat==7:
        ser.write('\x06'.encode());
    elif dat==8:
        ser.write('\x07'.encode());
    elif dat==9:
        ser.write('\x08'.encode());
    elif dat==10:
        ser.write('\x09'.encode());
    elif dat==11:
        ser.write('\x0a'.encode());
    elif dat==12:
        ser.write('\x0b'.encode());
    elif dat==13:
        ser.write('\x0c'.encode());
    elif dat==14:
        ser.write('\x0d'.encode());
    elif dat==15:
        ser.write('\x0e'.encode());
    elif dat==16:
        ser.write('\x0f'.encode());
    elif dat==17:
        ser.write('\x10'.encode());
    elif dat==18:
        ser.write('\x11'.encode());
    elif dat==19:
        ser.write('\x12'.encode());
    elif dat==20:
        ser.write('\x13'.encode());
    elif dat==21:
        ser.write('\x14'.encode());
    elif dat==22:
        ser.write('\x15'.encode());
    elif dat==23:
        ser.write('\x16'.encode());
    elif dat==24:
        ser.write('\x17'.encode());
    elif dat==25:
        ser.write('\x18'.encode());
    elif dat==26:
        ser.write('\x19'.encode());
    elif dat==27:
        ser.write('\x1a'.encode());
    return
      
number=0;        
def datdeal(state):
    number=int(state[5:7]);
    #print(number);
    usart_fpag(number);
        


def main():
    while True:
        count = ser.inWaiting()
        if count!=0:
            recv = ser.read(count)
            
            #if 'up' in str(recv):
             #   cityup_once()
            #elif 'down' in str(recv):
           #     citydown_once()
           # else:
           #     ser.write("d")
        ser.flushInput()
        time.sleep(0.1)
            


@get("/")
def index():
    return template("index")
@post("/cmd")
def cmd():
    state=request.body.read().decode()
    print("按下了按钮"+request.body.read().decode())
    datdeal(state)
    return "OK"
run(host="0.0.0.0")
